package com.ut.masterCode.enums;

public enum AuthProvider {
    local,
    facebook,
    google,
    github
}
