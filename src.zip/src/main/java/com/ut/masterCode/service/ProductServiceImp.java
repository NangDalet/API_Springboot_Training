package com.ut.masterCode.service;

import com.ut.masterCode.base.UserAuthSession;
import com.ut.masterCode.helper.ResponseMessageUtils;
import com.ut.masterCode.mapper.primary.ProductMapper;
import com.ut.masterCode.mapper.primary.UserMapper;
import com.ut.masterCode.model.MessageService;
import com.ut.masterCode.model.Product;
import com.ut.masterCode.model.Users.User;
import com.ut.masterCode.model.base.BaseResult;
import com.ut.masterCode.model.base.Filter;
import com.ut.masterCode.model.base.Pagination;
import com.ut.masterCode.model.base.ResponseMessage;
import com.ut.masterCode.model.request.Login.Product.ProductRequest;
import com.ut.masterCode.model.request.Login.Product.ProductUpdateRequest;
import com.ut.masterCode.model.response.CompanyResponse;
import com.ut.masterCode.model.response.EmployeeResponse;
import com.ut.masterCode.model.response.ProductResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImp implements ProductService {
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private ProductMapper productMapper;
    @Autowired
    private MessageService messageService;

    @Autowired
    private UserService userService;

    @Override
    public ResponseMessage<BaseResult> insert(ProductRequest productRequest) {
        Long userId = userService.getUserAuth().getId();
        //check Duplicate
        if (productMapper.checkDuplicate(productRequest.getName()) > 0) {
            return ResponseMessageUtils.makeResponse(true, messageService.message("Duplicate", false));
        }
        // check Data
        Product product = new Product(); //create new obj
        product.setName((productRequest.getName()));
        product.setPhoto(productRequest.getPhoto());
        product.setDescription(productRequest.getDescription());
        product.setCreatedBy(userId);
        product.setIsActive(1);
        Boolean result = productMapper.insert(product);
        if (result) {
            return ResponseMessageUtils.makeResponseByPermission(true, messageService.message("Success.", true));
        } else {
            return ResponseMessageUtils.makeResponseByPermission(true, messageService.message("Fail.", false));
        }
    }

    public User getUserAuth() {
        try {
            if (UserAuthSession.getUserAuth() != null) {
                List<User> userList = userMapper.getOneByUsername(UserAuthSession.getUserAuth().getUsername());
                return userList.get(0);
            } else {
                return new User();
            }
        } catch (Exception errorr) {
            return null;
        }
    }

    @Override
    public ResponseMessage<BaseResult> update(ProductUpdateRequest productUpdateRequest) {
        Long userId = userService.getUserAuth().getId();
        //check Duplicate
        if (productMapper.checkDuplicateUpdate(productUpdateRequest.getName(), productUpdateRequest.getId()) > 0) {
            return ResponseMessageUtils.makeResponse(true, messageService.message("Duplicate", false));
        }

        System.out.println(productUpdateRequest);
        //check data
        Product product = new Product(); //create new obj
        product.setId(productUpdateRequest.getId());
        product.setName(productUpdateRequest.getName());
        product.setPhoto(productUpdateRequest.getPhoto());
        product.setDescription(productUpdateRequest.getDescription());
        product.setModifiedBy(getUserAuth().getId());
        product.setIsActive(1);

        System.out.println(product);
        Boolean result = productMapper.update(product);

        if (result) {
            return ResponseMessageUtils.makeResponse(true, messageService.message("Success", true));
        } else {
            return ResponseMessageUtils.makeResponse(true, messageService.message("Fail", false));
        }
    }

    @Override
    public ResponseMessage<BaseResult> delete(Long id) {
        Boolean result = productMapper.delete(id);
        if (result) {
            return ResponseMessageUtils.makeResponse(true, messageService.message("Success", true));
        } else {
            return ResponseMessageUtils.makeResponse(true, messageService.message("Fail", false));
        }
    }

    @Override
    public ResponseMessage<BaseResult> list(Filter filter) {
        //pagination
        Pagination pagination = new Pagination();
        pagination.setPage(filter.getPage());
        pagination.setRowsPerPage(filter.getRowsPerPage());
        pagination.setTotal(productMapper.checkTotal());

        filter.setPage((filter.getPage() - 1) * filter.getRowsPerPage());
        List<CompanyResponse> productResponseList = productMapper.list(filter);
        return ResponseMessageUtils.makeResponse(true, messageService.message("Success", productResponseList, true));
    }

    @Override
    public ResponseMessage<BaseResult> getOne(Long id) {
        List<CompanyResponse> productResponses = productMapper.getOne(id);
        return ResponseMessageUtils.makeResponse(true, messageService.message("Success", productResponses, true));
    }
}
