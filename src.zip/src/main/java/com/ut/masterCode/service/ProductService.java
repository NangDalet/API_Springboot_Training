package com.ut.masterCode.service;

import com.ut.masterCode.model.base.BaseResult;
import com.ut.masterCode.model.base.Filter;
import com.ut.masterCode.model.base.ResponseMessage;
import com.ut.masterCode.model.request.Login.Product.ProductRequest;
import com.ut.masterCode.model.request.Login.Product.ProductUpdateRequest;
import com.ut.masterCode.model.request.Login.User.CompanyUpdateRequest;
import org.springframework.stereotype.Repository;

public interface ProductService {
    ResponseMessage<BaseResult> insert(ProductRequest productRequest);

    ResponseMessage<BaseResult> update(ProductUpdateRequest productUpdateRequest);

    ResponseMessage<BaseResult> delete(Long id);

    ResponseMessage<BaseResult> list(Filter filter);

    ResponseMessage<BaseResult> getOne(Long id);
}
