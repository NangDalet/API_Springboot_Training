package com.ut.masterCode.model.base;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class Pagination {

  @ApiModelProperty(position = 1)
  private Integer page;

  @ApiModelProperty(position = 2)
  private Integer rowsPerPage;

  @ApiModelProperty(position = 3)
  private Long total;

}