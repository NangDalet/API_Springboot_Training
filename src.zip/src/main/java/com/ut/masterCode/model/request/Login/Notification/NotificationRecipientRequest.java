package com.ut.masterCode.model.request.Login.Notification;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class NotificationRecipientRequest {

    @ApiModelProperty(position = 1, hidden = true)
    private Long id;

    @ApiModelProperty(position = 2, hidden = true)
    private Long notificationId;

    @ApiModelProperty(position = 3)
    private Long recipientId;

}
