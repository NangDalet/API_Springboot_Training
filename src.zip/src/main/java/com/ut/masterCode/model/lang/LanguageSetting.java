package com.ut.masterCode.model.lang;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

@Data
public class LanguageSetting implements Serializable {

  @ApiModelProperty(position = 1)
  private Long id;

  @ApiModelProperty(position = 2)
  private String deviceId;

  @ApiModelProperty(position = 3)
  private Long languageId;

}