package com.ut.masterCode.model.Users;

import com.ut.masterCode.model.base.Filter;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class UserFilter extends Filter {

  @ApiModelProperty(position = 101)
  private Long groupId;

}
