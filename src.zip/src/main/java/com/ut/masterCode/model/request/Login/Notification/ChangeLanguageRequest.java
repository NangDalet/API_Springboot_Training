package com.ut.masterCode.model.request.Login.Notification;


import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class ChangeLanguageRequest {

    @ApiModelProperty(position = 1)
    private String deviceId;

    @ApiModelProperty(position = 2)
    private String languageId;

}
