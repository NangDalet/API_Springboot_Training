package com.ut.masterCode.model.request.Login.Notification;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class UserDeviceNotificationRequest {

  @ApiModelProperty(position = 1)
  private Long appType;

  @ApiModelProperty(position = 2)
  private Long languageId;

  @ApiModelProperty(position = 2)
  private String deviceId;

  @ApiModelProperty(position = 3)
  private String deviceToken;

  @ApiModelProperty(position = 4)
  private String deviceName;

}