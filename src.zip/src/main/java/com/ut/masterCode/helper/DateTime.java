package com.ut.masterCode.helper;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class DateTime {

    public static String datetime() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
    }

}
